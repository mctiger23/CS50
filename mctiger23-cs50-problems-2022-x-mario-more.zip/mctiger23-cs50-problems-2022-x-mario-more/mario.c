#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int height;
//validation
    do
    {
        height = get_int("Height: ");
    }
    while (height <= 0 || height > 8);

    //loop throught height
    for (int i = 1; i <= height; i++)
    {
        //add space before hash
        for (int s = 0; s < (height - i); s++)
        {
            printf(" ");
        }
        //do for loop for each side of the pyramid
        //left side for loop
        for (int l = 0; l < i; l++)
        {
            printf("#");
        }
        //add space between pyramid
        printf("  ");
        //right side for loop
        for (int r = 0; r < i; r++)
        {
            printf("#");
        }
        printf("\n");
    }
}